This is a Menu program

Build Procedure:
    $ First Way: make, then  ./testmenu    to start program. 
    $ Second Way: gcc linktable.c menu.c testmenu.c -o testmenu
    $ ./testmenu    # you can input help & version & exit & dir cmd.

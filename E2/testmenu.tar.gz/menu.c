/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USET, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  HuangZhiheng                                                         */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIST RELEASE  :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 *Revision log:
 *
 *Created by HuangZhiheng, 2014/09/21
 *
 */

#define CMD_LEN 128
#define DESC_LEN 1024

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"linktable.h"
#include"menu.h"

/*data operation*/

tLinkTable *CreateMenu()
{
	tLinkTable *head = CreateLinkTable();
	return head;
}

int DeleteMenu(tLinkTable *head)
{
	DeleteLinkTable(head);
	return 0;
}

tDataNode *CreateCmd(tLinkTableNode *pNode, char *cmd, char *desc, int (*handler)())
{
    tDataNode *p = (tDataNode *)malloc(sizeof(tDataNode));
    p->pNext = pNode;
    strcpy(p->cmd, cmd);
    strcpy(p->desc, desc);
    p->handler = handler;
    return p;
}

int AddCmd(tLinkTable *head, tDataNode *p)
{
	if(head == NULL || p == NULL)
	{
		return 1;
	}
	AddLinkTableNode(head, (tLinkTableNode *)p);
	return 0;
}

int DeleteCmd(tLinkTable *head, tDataNode *p)
{
    DelLinkTableNode(head, (tLinkTableNode *)p);
	return 0;
}

tDataNode *FindCmd(tLinkTable *head, char *cmd)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, cmd))
        {
            return  pNode;  
        }
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return NULL;
    
}

int ShowAllCmd(tLinkTable *head)
{ 
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(head,(tLinkTableNode *)pNode);
    }
    return 0;
}


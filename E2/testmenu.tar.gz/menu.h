/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USET, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  HuangZhiheng                                                         */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIST RELEASE  :  2014/09/21                                                           */
/*  DESCRIPTION           :  interface of menu                                                    */
/**************************************************************************************************/

/*
 *Revision log:
 *
 *Created by HuangZhiheng, 2014/09/21
 *
 */

#ifndef _MENU_H_
#define _MENU_H

#define CMD_LEN 128
#define DESC_LEN 1024

#include"linktable.h"

/*data struct */

typedef struct DataNode
{
    tLinkTableNode * pNext;
    char    cmd[CMD_LEN];
    char    desc[DESC_LEN];
    int     (*handler)();
}tDataNode;

/*data operation*/

tLinkTable *CreateMenu();

int DeleteMenu(tLinkTable *head);

tDataNode *CreateCmd(tLinkTableNode *pNode, char *cmd, char *desc, int (*handler)());

int AddCmd(tLinkTable *head, tDataNode *p);

int DeleteCmd(tLinkTable *head, tDataNode *p);

tDataNode *FindCmd(tLinkTable *head, char *cmd);

int ShowAllCmd(tLinkTable *head);

#endif

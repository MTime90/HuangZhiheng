/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USET, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  HuangZhiheng                                                         */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIST RELEASE  :  2014/09/21                                                           */
/*  DESCRIPTION           :  interface of menu                                                    */
/**************************************************************************************************/

/*
 *Revision log:
 *
 *Created by HuangZhiheng, 2014/09/21
 *
 */

#define CMD_LEN 128
#define DESC_LEN 1024

#include"linktable.h"

/*data struct and its operation*/

typedef struct DataNode
{

	struct  LinkTableNode * pNext;
    char    cmd[CMD_LEN];
    char    desc[DESC_LEN];
    int     (*handler)();
}tDataNode;

/*data operation*/

tDataNode *FindCmd(tLinkTable *head, char *cmd);

int ShowAllCmd(tLinkTable *head);


This is a Menu program

Build Procedure:
    $ gcc linktable.c menu.c testmenu.c -o testmenu
    $ ./testmenu # you can input help & version & exit & dir cmd.

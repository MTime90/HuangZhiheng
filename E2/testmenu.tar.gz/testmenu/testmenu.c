/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USET, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  testmenu.c                                                           */
/*  PRINCIPAL AUTHOR      :  HuangZhiheng                                                         */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIST RELEASE  :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 *Revision log:
 *
 *Created by HuangZhiheng, 2014/09/21
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"linktable.h"
#include"menu.h"

/*menu data and operation*/

int Help();
int Exit();

static tDataNode data[] =
{
    {NULL, "version", "version 2.1", NULL},
    {NULL, "help", "This Program contain these cmd", Help},
    {NULL, "exit", "exit from this program", Exit},
    {NULL, "dir", "This is dir cmd", NULL}
};

/*program begain*/
    
tLinkTable * head = NULL;

int main()
{
    head = CreateLinkTable();
    AddLinkTableNode(head, (tLinkTableNode *)&data[0]);
    AddLinkTableNode(head, (tLinkTableNode *)&data[1]);
    AddLinkTableNode(head, (tLinkTableNode *)&data[2]);
    AddLinkTableNode(head, (tLinkTableNode *)&data[3]);

    while(1)
    {    
        char cmd[CMD_LEN];
        printf("Please input a cmd: ");
        scanf("%s", cmd);
        tDataNode *p = FindCmd(head, cmd);
        if(p == NULL)
        {
            printf("This is a wrong cmd\n");
            continue;
        }
        printf("%s %s\n", p->cmd, p->desc);
        if(p->handler != NULL)
        {
            p->handler();
        }
    }
    return 0;
}

int Help()
{
    ShowAllCmd(head);
    return 0;
}

int Exit()
{
    exit(0);
    return 0;
}

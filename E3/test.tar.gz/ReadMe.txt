This is a Menu test driver

Build Procedure:
    $ First Way: make, then  ./testmenu    to start program. 
    $ Second Way: gcc linktable.c menu.c test.c -o test
    $ ./test    # Test Report will display.

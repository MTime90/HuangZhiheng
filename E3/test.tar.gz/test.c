/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USET, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  HuangZhiheng                                                         */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIST RELEASE  :  2014/09/27                                                           */
/*  DESCRIPTION           :  This is a menu test driver                                           */
/**************************************************************************************************/

/*
 *Revision log:
 *
 *Created by HuangZhiheng, 2014/09/27
 *
 */

#include"linktable.h"
#include"menu.h"
#include<stdio.h>
#include<stdlib.h>

#define debug

int result[8] = {1, 1, 1, 1, 1, 1, 1, 1};
char * info[8] = {
    "Test Report:",
    "T1 CreateMenu",
    "T2 CreateCmd",
    "T3 AddCmd",
    "T4 DeleteCmd",
    "T5 FinCmd",
    "T6 ShowAllCmd",
    "T7 DeleteMenu"
};

int main()
{
    int i;
    int j;
    int k=2;
    tLinkTable *head = CreateMenu();
    char *str;
    tDataNode * t = (tDataNode *)malloc(sizeof(tDataNode)); 
    if(head == NULL)
    {
        debug("menu Create failed!\n");
        result[1] = 0;

    }

    tDataNode *p = CreateCmd(NULL,"test","test program",NULL);
    if(p == NULL)
    {
        debug("CreateCmd failed!\n");
        result[2] = 0;
    }

    i = AddCmd(head, p);
    if(i != 0)
    {
        debug("AddCmd failed!\n");
        result[3] = 0;
    }

    i = DeleteCmd(head, p);
    if(i != 0)
    {
        debug("DeleteCmd failed!\n");
        result[4] = 0;
    }
 
    tDataNode *p1 = CreateCmd(NULL,"test1","test1 program",NULL);
    str = "test1";
    AddCmd(head, p1);
    t = FindCmd(head, str);
    if(t == NULL)
    {
        debug("FindCmd failed!\n");
        result[5] = 0;
    }

    i = ShowAllCmd(head);
    if(i != 0)
    {
        debug("ShowAllCmd failed!\n");
        result[6] = 0;
    }

    i = DeleteMenu(head);
    if(i != 0)
    {
        debug("DeleteMenu failed!\n");
        result[7] = 0;
    }
    for(i=0;i<8;i++)
    {
        if(result[i] == 1)
        {
            printf("TestCase Number:%d  F - %s\n", i, info[i]);
        }
    }
    printf("Test MenuStart Please input %d\n", k);
    scanf("%d",&j);
    if(j == 2)
    {
        tLinkTable * head1 = CreateMenu();
        MenuStart(head1);
    }
    return 0;
}
